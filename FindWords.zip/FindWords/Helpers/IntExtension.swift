//
//  Helpers.swift
//  FindWords
//
//  Created by Norayr on 20.07.23.
//

import Foundation


import Foundation

extension Int {
    /// Get display formatted time from number of seconds
    /// E.g. 65s = 01:05
    ///
    /// - Returns: the display string
    func formattedTime() -> String {
        let seconds: Int = self % 60
        let minutes: Int = self / 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}
