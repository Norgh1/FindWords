//
//  GridCollectionViewCell.swift
//  FindWords
//
//  Created by Norayr on 21.07.23.
//

import UIKit

class GridCollectionViewCell: UICollectionViewCell {
    
    static let cellId = "GridCell"

    private let animationScaleFactor: CGFloat = 1.5

    @IBOutlet weak var label: UILabel!

    override var isSelected: Bool {
        didSet {
            label.textColor = .white
            label.font = UIFont(name: "Helvetica-Bold", size: 22)
            // Scale up the letter if it's selected.
            let transform = isSelected ? CGAffineTransform(scaleX: animationScaleFactor, y: animationScaleFactor) : .identity
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 5, options: [], animations: {
                self.label.transform = transform
            }) { (_) in }
        }
    }
    
    
}
