//
//  WordsCollectionViewCell.swift
//  FindWords
//
//  Created by Norayr on 22.07.23.
//

import UIKit

class WordsCollectionViewCell: UICollectionViewCell {
    
    
    static let cellID = "tcell"
    static let delegate = WordsCollectionViewCell(coder: NSCoder())
    
    @IBOutlet weak var letterLabel: UILabel!
    @IBOutlet weak var letterButton: UIButton!
    
    private var flipped: Bool = true {
        didSet {
            letterLabel.isHidden = flipped
            print("Here is it\(String(describing: letterLabel.text))")
        }
    }
    
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        print("Coder is called")
    }
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
}
