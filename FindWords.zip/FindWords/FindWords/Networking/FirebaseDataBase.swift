//
//  FirebaseDataBase.swift
//  FindWords
//
//  Created by Norayr on 27.07.23.
//


//import Foundation
//import FirebaseCore
//import FirebaseFirestore
//import FirebaseAuth
//
//
//final class FirebaseDataBase {
//    
//    var rederance: DatabaseReference!
//    
//    
//    
//    
//}
