//
//  IntExtension.swift
//  FindWords
//
//  Created by Norayr on 21.07.23.
//

import Foundation

extension Int {
    func formattedTime() -> String {
        let seconds: Int = self % 60
        let minutes: Int = self / 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}
