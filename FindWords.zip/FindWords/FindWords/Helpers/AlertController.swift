//
//  AlertController.swift
//  FindWords
//
//  Created by Norayr on 21.07.23.
//
import UIKit
import Foundation

extension MainViewController {
    func configureAlertController() {
        let alertController = UIAlertController(title: "Welcome to FindWords!", message: "Have a good time.", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
        }
        alertController.addAction(okAction)
        present(alertController, animated: false)
    }
}
