//
//  MainCoordinator.swift
//  FindWords
//
//  Created by Norayr on 26.07.23.
//

import Foundation

import UIKit

class MainCoordinator: Coordinator {
        
    var childCoordinators = [Coordinator]()
    var navigationController: UINavigationController

    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let vc = MainViewController.instantiate()
        navigationController.pushViewController(vc, animated: false)
    }
    func showWebController() {
        let vc = WebViewViewController.instantiate()
        navigationController.pushViewController(vc, animated: false)
    }
}
