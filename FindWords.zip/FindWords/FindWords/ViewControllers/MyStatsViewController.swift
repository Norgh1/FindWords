//
//  MyStatsViewController.swift
//  FindWords
//
//  Created by Norayr on 21.07.23.
//


import UIKit

class MyStatsViewController: UIViewController, ScoreProtocol {
  

    private var firstBaslineScore = String("")
    
    @IBOutlet weak var gamePlayedLabel: UILabel!
    @IBOutlet weak var scoreStatLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureLabels()
    }
    
    @IBAction func dissmissTapped(_ sender: Any) {
        self.dismiss(animated: true)
    }
    
    func getScoreLabel(_ scoreLabel: String) {
        self.scoreStatLabel.text = scoreLabel
        print(scoreLabel)
    }
    
    func gamePlayedLabel(_ gamePlayedLabel: String) {
        self.gamePlayedLabel.text = gamePlayedLabel
    }
}

extension MyStatsViewController {
    private func configureLabels() {
        self.scoreStatLabel.text = firstBaslineScore
        self.gamePlayedLabel.text = firstBaslineScore
    }
}
