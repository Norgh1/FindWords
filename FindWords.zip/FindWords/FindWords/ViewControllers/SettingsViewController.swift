//
//  SettingsViewController.swift
//  FindWords
//
//  Created by Norayr on 21.07.23.
//

import UIKit


class SettingsViewController: UIViewController {
        
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func dismissTapped(){
        self.dismiss(animated: true)
    }
}

extension SettingsViewController {

    
    
}
