//
//  ViewController.swift
//  FindWords
//
//  Created by Norayr on 20.07.23.
//

import UIKit
import WebKit

class MainViewController: UIViewController, Storyboarded {
    
    var gamevc: GameViewController?
    var mainvc: MyStatsViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presentingViewControllers()
        //configureAlertController()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    @IBAction func playTapped() {
        //configureWebView()
        self.present(gamevc!, animated: false)
    }
    
    @IBAction func settingsTapped() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "settingsid") as! SettingsViewController
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: false)
    }
    
    @IBAction func myStatsTapped() {
        if let mainvc {
            self.gamevc?.delegateScore = mainvc
            self.present(mainvc, animated: false)
        } else { return }
    }
    
}

extension MainViewController {
    
    private func presentingViewControllers() {
        self.gamevc?.delegateScore = mainvc
        gamevc = storyboard?.instantiateViewController(withIdentifier: "GameVC2") as? GameViewController
        gamevc?.modalPresentationStyle = .fullScreen
        mainvc = storyboard?.instantiateViewController(withIdentifier: "stateid") as? MyStatsViewController
        mainvc?.modalPresentationStyle = .fullScreen
    }
}
