//
//  WebViewViewController.swift
//  FindWords
//
//  Created by Norayr on 26.07.23.
//

import WebKit
import UIKit

class WebViewViewController: UIViewController, Storyboarded {
    
    var controller = MainCoordinator(navigationController: UINavigationController())
    
    private var url = URL(string: "https://www.google.com/")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureWebView()
    }
    
    @IBAction func dissmissMainViewController() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
        navigationController?.pushViewController(vc, animated: false)
    }
}
 
extension WebViewViewController {
    func showWebViewController() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "") as! WebViewViewController
        navigationController?.popToViewController(vc, animated: false)
    }
    
    func configureWebView() {
        let configuration = WKWebViewConfiguration()
        let view = WKWebView(frame: CGRect(x: view.frame.minX,
                                           y: 0,
                                           width: view.frame.width,
                                           height: view.frame.height),
                                            configuration: configuration)
        view.load(URLRequest(url: url!))
        self.view.addSubview(view)
    }
}
