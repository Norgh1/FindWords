//
//  ScoreProtocol.swift
//  FindWords
//
//  Created by Norayr on 24.07.23.
//
import UIKit
import Foundation

protocol ScoreProtocol: AnyObject {
    func getScoreLabel(_ scoreLabel: String)
    func gamePlayedLabel(_ gamePlayedLabel: String)
}
