//
//  AppDelegate.swift
//  FindWords
//
//  Created by Norayr on 20.07.23.
//
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth
import AppsFlyerLib
import UIKit
import OneSignal
import FirebaseDatabase

@main
class AppDelegate: UIResponder, UIApplicationDelegate, AppsFlyerLibDelegate, DeepLinkDelegate {
    
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        // Firebase
        FirebaseApp.configure()
        
        var ref = DatabaseReference()
        
        ref = Database.database().reference()
        
        print(" --------\(ref.root.description())")
        
        // Appsflayer
        
        AppsFlyerLib.shared().isDebug = true
        
        AppsFlyerLib.shared().appsFlyerDevKey = "dT5CDiZx9srN4bFhiCAtch"
        AppsFlyerLib.shared().appleAppID = "id6453942559"
        
        
        
        print(" ++++++++++++++++++++++++  \(AppsFlyerLib.shared().appleAppID)")
        
        
        
        AppsFlyerLib.shared().delegate = self
        AppsFlyerLib.shared().deepLinkDelegate = self
        
        
        //Log Evant
        
        AppsFlyerLib.shared().logEvent(AFEventAddToWishlist,
          withValues: [
             AFEventParamPrice: 20,
             AFEventParamContentId: "123456",
             AFEventInvite: "simple String"
        ])
        
        // Callback
        
        AppsFlyerLib.shared().logEvent(name: "In app event name", values: ["id": 12345, "name": "John doe"], completionHandler: { (response: [String : Any]?, error: Error?) in
                     if let response = response {
                       print("In app event callback Success: ", response)
                     }
                     if let error = error {
                       print("In app event callback ERROR:", error)
                     }
                   })
    
        
        
        NotificationCenter.default.addObserver(self, selector: NSSelectorFromString("sendLaunch"), name: UIApplication.didBecomeActiveNotification, object: nil)

        
       
        
        
        window?.rootViewController = WebViewViewController()
        window?.makeKeyAndVisible()
        
        //One Signal configuration
        
        OneSignal.setLogLevel(.LL_VERBOSE, visualLevel: .LL_NONE)
        OneSignal.initWithLaunchOptions(launchOptions)
        OneSignal.setAppId("b8267861-5e37-4fe4-acd0-b781656a1219")   /// 8e330e47-c512-4bf2-8e53-d38619800370
        
        OneSignal.promptForPushNotifications(userResponse: { accepted in
           print("User accepted notifications: \(accepted)")
         })
        
        
        return true
    }
    
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
            AppsFlyerLib.shared().handleOpen(url, options: options)
            return true
        }
        
        // Report Push Notification attribution data for re-engagements
        func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
            AppsFlyerLib.shared().handlePushNotification(userInfo)
        }
    
    
    func onConversionDataSuccess(_ conversionInfo: [AnyHashable : Any]) {
        print("Keys ++++++++ \(conversionInfo.keys), Value ++++++ \(conversionInfo.values)")
    }
    
    func onConversionDataFail(_ error: Error) {
           NSLog("[AFSDK] \(error)")
       }
    
    @objc func sendLaunch() {
        AppsFlyerLib.shared().start()
    }
    
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
    }
    
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        AppsFlyerLib().start()
    }
}

